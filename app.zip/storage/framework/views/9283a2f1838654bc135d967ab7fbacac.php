<li>
    <?php if(isset($items) && count($items) > 0): ?>
        <!-- Çoklu Menü (Dropdown) -->
        <a href="#<?php echo e($id); ?>" data-bs-toggle="collapse">
            <i data-feather="<?php echo e($icon); ?>"></i>
            <span> <?php echo e($title); ?> </span>
            <span class="menu-arrow"></span>
        </a>
        <div class="collapse" id="<?php echo e($id); ?>">
            <ul class="nav-second-level">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(isset($item['link']) ? $item['link'] : route($item['route'])); ?>" class="tp-link">
                            <?php echo e($item['name']); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php else: ?>
        <!-- Tekli Menü -->
        <a href="<?php echo e(isset($link) ? $link : route($route)); ?>">
            <i data-feather="<?php echo e($icon); ?>"></i>
            <span> <?php echo e($title); ?> </span>
        </a>
    <?php endif; ?>
</li>
<?php /**PATH /Users/yunusemregok/Desktop/Discord/discord-bot-panel/resources/views/components/menu-item.blade.php ENDPATH**/ ?>