<?php $__env->startSection('title','Anasayfa'); ?>

<?php $__env->startSection('content'); ?>
Mesaj
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yunusemregok/Desktop/Discord/discord-bot-panel/resources/views/panel/home.blade.php ENDPATH**/ ?>