<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Rolü Düzenle: <?php echo e($role->name); ?></h1>
        <form action="<?php echo e(route('roles.update', $role)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="name">Rol Adı</label>
                <input type="text" name="name" class="form-control" value="<?php echo e($role->name); ?>" required>
            </div>
            <div class="form-group">
                <label for="permissions">İzinler</label>
                <select name="permissions[]" multiple class="form-control">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($permission->name); ?>" <?php echo e(in_array($permission->id, $rolePermissions) ? 'selected' : ''); ?>>
                            <?php echo e($permission->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-success">Güncelle</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yunusemregok/Desktop/Discord/discord-bot-panel/resources/views/roles/edit.blade.php ENDPATH**/ ?>