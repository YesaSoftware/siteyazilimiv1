<?php $__env->startSection('title', $role->name .  ' İzinleri'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1><?php echo $__env->yieldContent('title'); ?></h1>

        <form action="<?php echo e(route('panel.roles.permission.update',$role->id)); ?>" method="POST" onsubmit="return disableButton(this);">
            <?php echo csrf_field(); ?>

            <?php $__currentLoopData = $permissionGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3"> <!-- Bootstrap kartı -->
                    <div class="card-header">
                        <h4><?php echo e($group->title); ?></h4> <!-- Grup başlığı -->
                    </div>
                    <div class="card-body">
                        <div class="d-flex align-items-center" style="flex-wrap: wrap;">
                            <?php $__currentLoopData = $group->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check" style="margin-right: 10px">
                                    <input type="checkbox" class="form-check-input" id="permission_<?php echo e($permission->id); ?>"
                                           name="permissions[]" value="<?php echo e($permission->id); ?>"
                                        <?php echo e($role->permissions->contains($permission->id) ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="permission_<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></label>
                                </div>
                                <!-- Son izin dışında '|' ekle -->
                                <?php if(!$loop->last): ?>
                                    <span style="margin-right: 10px;">|</span>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- Gruplandırılmamış izinler -->
            <div class="card mb-3"> <!-- Bootstrap kartı -->
                <div class="card-header">
                    <h4>Gruplandırılmamış İzinler</h4>
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center" style="flex-wrap: wrap;">
                        <?php $__currentLoopData = $ungroupedPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check" style="margin-right: 10px">
                                <input type="checkbox" class="form-check-input" id="permission_<?php echo e($permission->id); ?>"
                                       name="permissions[]" value="<?php echo e($permission->id); ?>"
                                    <?php echo e($role->permissions->contains($permission->id) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="permission_<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></label>
                            </div>
                            <!-- Son izin dışında '|' ekle -->
                            <?php if(!$loop->last): ?>
                                <span style="margin-right: 10px;">|</span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" id="submitButton">Kaydet</button>
            <span id="loadingMessage" class="text-danger ms-2" style="display: none;">İşlem bitene kadar lütfen bekleyiniz...</span>
        </form>
    </div>

    <script>
        function disableButton(form) {
            // Butonu devre dışı bırak
            const button = document.getElementById('submitButton');
            button.disabled = true;

            // Bekleme mesajını göster
            const loadingMessage = document.getElementById('loadingMessage');
            loadingMessage.style.display = 'inline';

            // Formun gönderilmesine izin ver
            return true;
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yunusemregok/Desktop/Discord/discord-bot-panel/resources/views/panel/roles/permissionList.blade.php ENDPATH**/ ?>