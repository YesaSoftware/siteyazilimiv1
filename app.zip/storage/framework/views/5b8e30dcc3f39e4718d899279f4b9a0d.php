<?php $__env->startSection('title','Rol | Listeleme'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">


                <div class="card-body">
                    <?php if (isset($component)) { $__componentOriginalb539fdd4bceece4a667dd360eb69c7ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb539fdd4bceece4a667dd360eb69c7ae = $attributes; } ?>
<?php $component = App\View\Components\DataTable::resolve(['columns' => ['id', 'name'],'route' => 'panel.roles.list.data','options' => [
                                    'order' => [[0, 'asc']], // Sıralama
                                    'paging' => true, // Sayfalama
                                    'searching' => true, // Arama
                        ],'columnButtons' => [
                            ['href' => route('panel.roles.permission.list', ['id' => ':id']), 'class' => 'btn btn-success', 'title' => 'İzinleri'],
                        ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DataTable::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb539fdd4bceece4a667dd360eb69c7ae)): ?>
<?php $attributes = $__attributesOriginalb539fdd4bceece4a667dd360eb69c7ae; ?>
<?php unset($__attributesOriginalb539fdd4bceece4a667dd360eb69c7ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb539fdd4bceece4a667dd360eb69c7ae)): ?>
<?php $component = $__componentOriginalb539fdd4bceece4a667dd360eb69c7ae; ?>
<?php unset($__componentOriginalb539fdd4bceece4a667dd360eb69c7ae); ?>
<?php endif; ?>

                </div>

            </div>
        </div>
    </div>

    <script>

        function deleteFunction(id)
        {
            document.getElementById('urlFrameModal_Url').src = '';

            const url = "<?php echo e(route('panel.roles.permission.list',[''])); ?>" + '/' +  id
            document.getElementById('urlFrameModal_Url').src = url;
            $('#urlPopup').modal({
                backdrop: 'static',
                keyboard: false,
            });
            $('#urlPopup').modal('show');

        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yunusemregok/Desktop/Discord/discord-bot-panel/resources/views/panel/roles/index.blade.php ENDPATH**/ ?>