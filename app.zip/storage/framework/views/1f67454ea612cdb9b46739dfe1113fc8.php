<!-- resources/views/components/data-table.blade.php -->
<table id="dataTable" class="table table-striped table-bordered">
    <thead>
    <tr>
        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($column); ?></th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!empty($columnButtons)): ?>
            <th class="actions-header">İşlemler</th> <!-- Butonlar için başlık -->
        <?php endif; ?>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        $(document).ready(function() {
            $('#dataTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: '<?php echo route($route); ?>',
                columns: [
                        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    { data: '<?php echo e($column); ?>', name: '<?php echo e($column); ?>' },
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($columnButtons)): ?>
                    { data: null, render: function(data, type, row) {
                            return <?php echo json_encode($columnButtons, 15, 512) ?>.map(button => {
                                // URL'nin dinamik olarak oluşturulması
                                let url = button.href ? button.href.replace(':id', row.id) : '#';
                                if (button.function) {
                                    // Eğer bir fonksiyon belirtilmişse, butonu oluştur
                                    return `<button class="${button.class}" onclick="${button.function}(${row.id})">${button.title}</button>`;
                                } else {
                                    // Aksi halde bir link oluştur
                                    return `<a href="${url}" target="_blank" class="${button.class}">${button.title}</a>`;
                                }
                            }).join(' ');
                        }},
                    <?php endif; ?>
                ],
                columnDefs: [
                        <?php if(!empty($columnButtons)): ?>
                    {
                        targets: -1, // Aksiyon butonları için son sütun
                        orderable: false // Sıralamayı devre dışı bırak
                    },
                    <?php endif; ?>
                    // Diğer columnDefs ayarları burada yapılabilir
                ],
                <?php if(!empty($options)): ?>
                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($key); ?>: <?php echo json_encode($value); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            });
        });
    });
</script>

<style>
    /* İşlemler sütunu için özel stil */
    .actions-header {
        width: 15%; /* Bu alanda istediğin genişliği ayarlayabilirsin */
    }
</style>
<?php /**PATH /Users/yunusemregok/Desktop/Discord/discord-bot-panel/resources/views/components/data-table.blade.php ENDPATH**/ ?>