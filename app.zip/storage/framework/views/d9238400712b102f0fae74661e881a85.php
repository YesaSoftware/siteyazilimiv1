<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e($_SERVER['HTTP_HOST']); ?> Yönetim Paneli</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc."/>
    <meta name="author" content="Zoyothemes"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->


    <!-- App css -->
    <link href="<?php echo e(asset('/admin_1529321/assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style" />

    <!-- Icons -->

    <link href="<?php echo e(asset('/admin_1529321/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />

</head>

<!-- body start -->
<body data-menu-color="light" data-sidebar="default">

<!-- Begin page -->
<div id="app-layout">


    <!-- Topbar Start -->
    <!-- end Topbar -->

    <!-- Left Sidebar Start -->
    <!-- Left Sidebar End -->

    <!-- ============================================================== -->
    <!-- Start Page Content here -->
    <!-- ============================================================== -->

    <div class="">
        <div class="">

            <!-- Start Content-->
            <div class="">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                    </div>
                <?php endif; ?>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?> | Popup'ı kapatabilirsiniz.
                        </div>
                    <?php endif; ?>

                    <!-- Error Alert -->
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e(session('error')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                        </div>
                    <?php endif; ?>



                <?php echo $__env->yieldContent('content'); ?>

            </div> <!-- container-fluid -->
        </div> <!-- content -->



    </div>
    <!-- ============================================================== -->
    <!-- End Page content -->
    <!-- ============================================================== -->

</div>
<!-- END wrapper -->

<!-- Vendor -->
<script src="<?php echo e(asset('/admin_1529321/assets/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('/admin_1529321/assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/admin_1529321/assets/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('/admin_1529321/assets/libs/node-waves/waves.min.js')); ?>"></script>
<script src="<?php echo e(asset('/admin_1529321/assets/libs/waypoints/lib/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('/admin_1529321/assets/libs/jquery.counterup/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('/admin_1529321/assets/libs/feather-icons/feather.min.js')); ?>"></script>


<!-- App js-->
<script src="<?php echo e(asset('/admin_1529321/assets/js/app.js')); ?>"></script>


</body>
</html>
<?php /**PATH /Users/yunusemregok/Desktop/Discord/discord-bot-panel/resources/views/layouts/modal_panel.blade.php ENDPATH**/ ?>