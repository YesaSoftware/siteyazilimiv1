<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>İzinler</h1>
        <a href="<?php echo e(route('permissions.create')); ?>" class="btn btn-primary">Yeni İzin Oluştur</a>
        <table class="table">
            <thead>
            <tr>
                <th>İzin Adı</th>
                <th>İşlem</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($permission->name); ?></td>
                    <td>
                        <a href="<?php echo e(route('permissions.edit', $permission)); ?>" class="btn btn-warning">Düzenle</a>
                        <form action="<?php echo e(route('permissions.destroy', $permission)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Sil</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yunusemregok/Desktop/Discord/discord-bot-panel/resources/views/permissions/index.blade.php ENDPATH**/ ?>