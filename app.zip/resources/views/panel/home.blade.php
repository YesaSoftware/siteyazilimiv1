@extends('layouts.panel')
@section('title',__('general.anasayfa'))

@section('content')
    <div class="row">
        <div class="col-md-6 col-xl-3">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <p class="text-muted mb-3 fw-semibold">Toplam Üye Sayısı</p>
                            <h4 class="m-0 mb-3 fs-18">{{dashboardHelperTotalUsers()}}</h4>

                        </div>
                    </div>
                </div> <!-- end cardbody -->
            </div> <!-- end card -->
        </div> <!-- end col -->

    </div>
@endsection
