<?php


return [
    'anasayfa' => 'Home',
    'listeleme' => 'List',
    'ekleme' => 'Create',
    'güncelleme' => 'Edit',
    'silme' => 'Delete',
    'verileri_yenile' => 'Refresh Data',
];
