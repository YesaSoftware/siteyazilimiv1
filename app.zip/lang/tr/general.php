<?php

return [
    'anasayfa' => 'Anasayfa',
    'listeleme' => 'Listeleme',
    'ekleme' => 'Ekleme',
    'güncelleme' => 'Güncelleme',
    'silme' => 'Silme',
    'verileri_yenile' => 'Verileri Yenile',
];
